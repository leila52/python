class Nodo:
    def __init__(self, info=None, enlace=None):
        self.info = info
        self.enlace = enlace
